
# from __future__ import absolute_import

# from path import Path

# class PiperJSON(object):

#     def __init__(self):
#         pass

#     def addDependency(line, depends_on, dev=False):
#         pass

#     def removeDependency(line):
#         pass


