import os
import sys

# sys.path.append(0, os.path.join(".."))

def test_init():
    pass

def test_add():
    pass

def test_remove():
    pass

def test_install():
    pass